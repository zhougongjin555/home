

HOST = '127.0.0.1'
PORT = 3306
USER = 'root'
PASSWORD = 'bt254618'
DATABASE = 'blog'
TAB_USERS = 'users'
TAB_BRIEF = 'brief'
TAB_CONTENTS = 'contents'
TAB_COMMENTS = 'comments'