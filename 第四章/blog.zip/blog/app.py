from utils.blog_view import blogview

if __name__ == '__main__':
    viewer = blogview()
    viewer.run()
